﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace QLHS.Report
{
    public partial class DSLop : DevExpress.XtraReports.UI.XtraReport
    {
        public DSLop()
        {
            InitializeComponent();
        }

    }
}
