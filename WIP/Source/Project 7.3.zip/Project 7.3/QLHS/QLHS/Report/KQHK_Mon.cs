﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace QLHS.Report
{
    public partial class KQHK_Mon : DevExpress.XtraReports.UI.XtraReport
    {
        public KQHK_Mon()
        {
            InitializeComponent();
        }

    }
}
