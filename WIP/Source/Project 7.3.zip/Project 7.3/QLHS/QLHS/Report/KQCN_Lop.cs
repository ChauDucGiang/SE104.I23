﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace QLHS.Report
{
    public partial class KQCN_Lop : DevExpress.XtraReports.UI.XtraReport
    {
        public KQCN_Lop()
        {
            InitializeComponent();
        }

    }
}
