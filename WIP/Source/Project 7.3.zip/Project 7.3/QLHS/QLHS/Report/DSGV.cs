﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace QLHS.Report
{
    public partial class DSGV : DevExpress.XtraReports.UI.XtraReport
    {
        public DSGV()
        {
            InitializeComponent();
        }

    }
}
