﻿namespace QLHS.GUI
{
    partial class frmPL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions windowsUIButtonImageOptions1 = new DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions();
            DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions windowsUIButtonImageOptions2 = new DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions();
            DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions windowsUIButtonImageOptions3 = new DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions();
            DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions windowsUIButtonImageOptions4 = new DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions();
            DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions windowsUIButtonImageOptions5 = new DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions();
            DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions windowsUIButtonImageOptions6 = new DevExpress.XtraBars.Docking2010.WindowsUIButtonImageOptions();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.windowsUIButtonPanel1 = new DevExpress.XtraBars.Docking2010.WindowsUIButtonPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dGvLopcu = new System.Windows.Forms.DataGridView();
            this.colMahocsinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenhocsinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGioiTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgaysinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNoisinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDienthoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDiachi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.lblLopcu = new System.Windows.Forms.Label();
            this.lblKhoilopcu = new System.Windows.Forms.Label();
            this.lblNamhoccu = new System.Windows.Forms.Label();
            this.cmbLopcu = new System.Windows.Forms.ComboBox();
            this.cmbKhoilopcu = new System.Windows.Forms.ComboBox();
            this.cmbNamhoccu = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dGvLopmoi = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.lblLopmoi = new System.Windows.Forms.Label();
            this.cmbNamhocmoi = new System.Windows.Forms.ComboBox();
            this.cmbKhoilopmoi = new System.Windows.Forms.ComboBox();
            this.lblKhoilopmoi = new System.Windows.Forms.Label();
            this.cmbLopmoi = new System.Windows.Forms.ComboBox();
            this.lblNamhocmoi = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGvLopcu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGvLopmoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.windowsUIButtonPanel1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(600, 366);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // windowsUIButtonPanel1
            // 
            windowsUIButtonImageOptions1.Image = global::QLHS.Properties.Resources.rsz_hanhkiem;
            windowsUIButtonImageOptions2.Image = global::QLHS.Properties.Resources.rsz_arrow_1314470_960_720;
            windowsUIButtonImageOptions3.Image = global::QLHS.Properties.Resources.rsz_double_arrow_right_bolded_512;
            windowsUIButtonImageOptions4.Image = global::QLHS.Properties.Resources.delete;
            windowsUIButtonImageOptions5.Image = global::QLHS.Properties.Resources.save;
            windowsUIButtonImageOptions6.Image = global::QLHS.Properties.Resources.thoat;
            this.windowsUIButtonPanel1.Buttons.AddRange(new DevExpress.XtraEditors.ButtonPanel.IBaseButton[] {
            new DevExpress.XtraBars.Docking2010.WindowsUIButton("Danh sách học sinh chưa có lớp", false, windowsUIButtonImageOptions1, DevExpress.XtraBars.Docking2010.ButtonStyle.CheckButton, "Danh sách học sinh chưa có lớp", -1, true, null, true, false, true, "chkDSHS", -1, false),
            new DevExpress.XtraBars.Docking2010.WindowsUISeparator(),
            new DevExpress.XtraBars.Docking2010.WindowsUIButton("Add", true, windowsUIButtonImageOptions2, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "", -1, true, null, true, false, true, "btnAdd", -1, false),
            new DevExpress.XtraBars.Docking2010.WindowsUISeparator(),
            new DevExpress.XtraBars.Docking2010.WindowsUIButton("Add All", true, windowsUIButtonImageOptions3, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "", -1, true, null, true, false, true, "btnAddall", -1, false),
            new DevExpress.XtraBars.Docking2010.WindowsUISeparator(),
            new DevExpress.XtraBars.Docking2010.WindowsUIButton("Delete", true, windowsUIButtonImageOptions4, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "", -1, true, null, true, false, true, "btnDelete", -1, false),
            new DevExpress.XtraBars.Docking2010.WindowsUISeparator(),
            new DevExpress.XtraBars.Docking2010.WindowsUIButton("Save", true, windowsUIButtonImageOptions5, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "", -1, true, null, true, false, true, "btnSave", -1, false),
            new DevExpress.XtraBars.Docking2010.WindowsUISeparator(),
            new DevExpress.XtraBars.Docking2010.WindowsUIButton("Exit", true, windowsUIButtonImageOptions6, DevExpress.XtraBars.Docking2010.ButtonStyle.PushButton, "", -1, true, null, true, false, true, "btnExit", -1, false)});
            this.windowsUIButtonPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.windowsUIButtonPanel1.Location = new System.Drawing.Point(272, 2);
            this.windowsUIButtonPanel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.windowsUIButtonPanel1.Name = "windowsUIButtonPanel1";
            this.windowsUIButtonPanel1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.windowsUIButtonPanel1.Size = new System.Drawing.Size(56, 362);
            this.windowsUIButtonPanel1.TabIndex = 0;
            this.windowsUIButtonPanel1.Text = "windowsUIButtonPanel1";
            this.windowsUIButtonPanel1.ButtonClick += new DevExpress.XtraBars.Docking2010.ButtonEventHandler(this.windowsUIButtonPanel1_ButtonClick);
            this.windowsUIButtonPanel1.ButtonUnchecked += new DevExpress.XtraBars.Docking2010.ButtonEventHandler(this.windowsUIButtonPanel1_ButtonUnchecked);
            this.windowsUIButtonPanel1.ButtonChecked += new DevExpress.XtraBars.Docking2010.ButtonEventHandler(this.windowsUIButtonPanel1_ButtonChecked);
            this.windowsUIButtonPanel1.Click += new System.EventHandler(this.windowsUIButtonPanel1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dGvLopcu);
            this.panel1.Controls.Add(this.groupControl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(266, 362);
            this.panel1.TabIndex = 1;
            // 
            // dGvLopcu
            // 
            this.dGvLopcu.AllowUserToAddRows = false;
            this.dGvLopcu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGvLopcu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGvLopcu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMahocsinh,
            this.colTenhocsinh,
            this.colGioiTinh,
            this.colNgaysinh,
            this.colNoisinh,
            this.colDienthoai,
            this.colEmail,
            this.colDiachi});
            this.dGvLopcu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGvLopcu.Location = new System.Drawing.Point(0, 124);
            this.dGvLopcu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dGvLopcu.Name = "dGvLopcu";
            this.dGvLopcu.RowHeadersWidth = 39;
            this.dGvLopcu.RowTemplate.Height = 24;
            this.dGvLopcu.Size = new System.Drawing.Size(266, 238);
            this.dGvLopcu.TabIndex = 2;
            // 
            // colMahocsinh
            // 
            this.colMahocsinh.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colMahocsinh.DataPropertyName = "MaHS";
            this.colMahocsinh.HeaderText = "Mã Học Sinh";
            this.colMahocsinh.Name = "colMahocsinh";
            this.colMahocsinh.ReadOnly = true;
            // 
            // colTenhocsinh
            // 
            this.colTenhocsinh.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTenhocsinh.DataPropertyName = "HoTen";
            this.colTenhocsinh.HeaderText = "Tên Học Sinh";
            this.colTenhocsinh.Name = "colTenhocsinh";
            this.colTenhocsinh.ReadOnly = true;
            // 
            // colGioiTinh
            // 
            this.colGioiTinh.HeaderText = "Giới tính";
            this.colGioiTinh.Name = "colGioiTinh";
            this.colGioiTinh.ReadOnly = true;
            this.colGioiTinh.Visible = false;
            // 
            // colNgaysinh
            // 
            this.colNgaysinh.HeaderText = "Ngày Sinh";
            this.colNgaysinh.Name = "colNgaysinh";
            this.colNgaysinh.ReadOnly = true;
            this.colNgaysinh.Visible = false;
            // 
            // colNoisinh
            // 
            this.colNoisinh.HeaderText = "Nơi Sinh";
            this.colNoisinh.Name = "colNoisinh";
            this.colNoisinh.ReadOnly = true;
            this.colNoisinh.Visible = false;
            // 
            // colDienthoai
            // 
            this.colDienthoai.HeaderText = "Điện Thoại";
            this.colDienthoai.Name = "colDienthoai";
            this.colDienthoai.ReadOnly = true;
            this.colDienthoai.Visible = false;
            // 
            // colEmail
            // 
            this.colEmail.HeaderText = "Email";
            this.colEmail.Name = "colEmail";
            this.colEmail.ReadOnly = true;
            this.colEmail.Visible = false;
            // 
            // colDiachi
            // 
            this.colDiachi.HeaderText = "Địa Chỉ";
            this.colDiachi.Name = "colDiachi";
            this.colDiachi.ReadOnly = true;
            this.colDiachi.Visible = false;
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.lblLopcu);
            this.groupControl1.Controls.Add(this.lblKhoilopcu);
            this.groupControl1.Controls.Add(this.lblNamhoccu);
            this.groupControl1.Controls.Add(this.cmbLopcu);
            this.groupControl1.Controls.Add(this.cmbKhoilopcu);
            this.groupControl1.Controls.Add(this.cmbNamhoccu);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControl1.Location = new System.Drawing.Point(0, 0);
            this.groupControl1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(266, 124);
            this.groupControl1.TabIndex = 1;
            this.groupControl1.Text = "Thông tin lớp cũ";
            // 
            // lblLopcu
            // 
            this.lblLopcu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLopcu.AutoSize = true;
            this.lblLopcu.Location = new System.Drawing.Point(5, 98);
            this.lblLopcu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLopcu.Name = "lblLopcu";
            this.lblLopcu.Size = new System.Drawing.Size(24, 13);
            this.lblLopcu.TabIndex = 1;
            this.lblLopcu.Text = "Lớp";
            // 
            // lblKhoilopcu
            // 
            this.lblKhoilopcu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblKhoilopcu.AutoSize = true;
            this.lblKhoilopcu.Location = new System.Drawing.Point(5, 64);
            this.lblKhoilopcu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKhoilopcu.Name = "lblKhoilopcu";
            this.lblKhoilopcu.Size = new System.Drawing.Size(44, 13);
            this.lblKhoilopcu.TabIndex = 1;
            this.lblKhoilopcu.Text = "Khối lớp";
            // 
            // lblNamhoccu
            // 
            this.lblNamhoccu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNamhoccu.AutoSize = true;
            this.lblNamhoccu.Location = new System.Drawing.Point(5, 30);
            this.lblNamhoccu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNamhoccu.Name = "lblNamhoccu";
            this.lblNamhoccu.Size = new System.Drawing.Size(48, 13);
            this.lblNamhoccu.TabIndex = 1;
            this.lblNamhoccu.Text = "Năm học";
            // 
            // cmbLopcu
            // 
            this.cmbLopcu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbLopcu.FormattingEnabled = true;
            this.cmbLopcu.Location = new System.Drawing.Point(105, 96);
            this.cmbLopcu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbLopcu.Name = "cmbLopcu";
            this.cmbLopcu.Size = new System.Drawing.Size(158, 21);
            this.cmbLopcu.TabIndex = 0;
            this.cmbLopcu.SelectedIndexChanged += new System.EventHandler(this.cmbLopcu_SelectedIndexChanged);
            // 
            // cmbKhoilopcu
            // 
            this.cmbKhoilopcu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbKhoilopcu.FormattingEnabled = true;
            this.cmbKhoilopcu.Location = new System.Drawing.Point(105, 62);
            this.cmbKhoilopcu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbKhoilopcu.Name = "cmbKhoilopcu";
            this.cmbKhoilopcu.Size = new System.Drawing.Size(158, 21);
            this.cmbKhoilopcu.TabIndex = 0;
            this.cmbKhoilopcu.SelectedIndexChanged += new System.EventHandler(this.cmbKhoilopcu_SelectedIndexChanged);
            // 
            // cmbNamhoccu
            // 
            this.cmbNamhoccu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbNamhoccu.FormattingEnabled = true;
            this.cmbNamhoccu.Location = new System.Drawing.Point(105, 25);
            this.cmbNamhoccu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbNamhoccu.Name = "cmbNamhoccu";
            this.cmbNamhoccu.Size = new System.Drawing.Size(158, 21);
            this.cmbNamhoccu.TabIndex = 0;
            this.cmbNamhoccu.SelectedIndexChanged += new System.EventHandler(this.cmbNamhoccu_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dGvLopmoi);
            this.panel2.Controls.Add(this.groupControl2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(332, 2);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(266, 362);
            this.panel2.TabIndex = 2;
            // 
            // dGvLopmoi
            // 
            this.dGvLopmoi.AllowUserToAddRows = false;
            this.dGvLopmoi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGvLopmoi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGvLopmoi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.dGvLopmoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGvLopmoi.Location = new System.Drawing.Point(0, 124);
            this.dGvLopmoi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dGvLopmoi.Name = "dGvLopmoi";
            this.dGvLopmoi.RowHeadersWidth = 39;
            this.dGvLopmoi.Size = new System.Drawing.Size(266, 238);
            this.dGvLopmoi.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "MaHS";
            this.dataGridViewTextBoxColumn1.HeaderText = "Mã Học Sinh";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "HoTen";
            this.dataGridViewTextBoxColumn2.HeaderText = "Tên Học Sinh";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Giới Tính";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Ngày Sinh";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Nơi Sinh";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Visible = false;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Điện Thoại";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Visible = false;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Email";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Visible = false;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Địa Chỉ";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Visible = false;
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.lblLopmoi);
            this.groupControl2.Controls.Add(this.cmbNamhocmoi);
            this.groupControl2.Controls.Add(this.cmbKhoilopmoi);
            this.groupControl2.Controls.Add(this.lblKhoilopmoi);
            this.groupControl2.Controls.Add(this.cmbLopmoi);
            this.groupControl2.Controls.Add(this.lblNamhocmoi);
            this.groupControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControl2.Location = new System.Drawing.Point(0, 0);
            this.groupControl2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(266, 124);
            this.groupControl2.TabIndex = 1;
            this.groupControl2.Text = "Thông tin lớp mới";
            // 
            // lblLopmoi
            // 
            this.lblLopmoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLopmoi.AutoSize = true;
            this.lblLopmoi.Location = new System.Drawing.Point(13, 98);
            this.lblLopmoi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLopmoi.Name = "lblLopmoi";
            this.lblLopmoi.Size = new System.Drawing.Size(24, 13);
            this.lblLopmoi.TabIndex = 1;
            this.lblLopmoi.Text = "Lớp";
            // 
            // cmbNamhocmoi
            // 
            this.cmbNamhocmoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbNamhocmoi.FormattingEnabled = true;
            this.cmbNamhocmoi.Location = new System.Drawing.Point(112, 25);
            this.cmbNamhocmoi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbNamhocmoi.Name = "cmbNamhocmoi";
            this.cmbNamhocmoi.Size = new System.Drawing.Size(148, 21);
            this.cmbNamhocmoi.TabIndex = 0;
            this.cmbNamhocmoi.SelectedIndexChanged += new System.EventHandler(this.cmbNamhocmoi_SelectedIndexChanged);
            // 
            // cmbKhoilopmoi
            // 
            this.cmbKhoilopmoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbKhoilopmoi.FormattingEnabled = true;
            this.cmbKhoilopmoi.Location = new System.Drawing.Point(112, 62);
            this.cmbKhoilopmoi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbKhoilopmoi.Name = "cmbKhoilopmoi";
            this.cmbKhoilopmoi.Size = new System.Drawing.Size(148, 21);
            this.cmbKhoilopmoi.TabIndex = 0;
            this.cmbKhoilopmoi.SelectedIndexChanged += new System.EventHandler(this.cmbKhoilopmoi_SelectedIndexChanged);
            // 
            // lblKhoilopmoi
            // 
            this.lblKhoilopmoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblKhoilopmoi.AutoSize = true;
            this.lblKhoilopmoi.Location = new System.Drawing.Point(13, 64);
            this.lblKhoilopmoi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKhoilopmoi.Name = "lblKhoilopmoi";
            this.lblKhoilopmoi.Size = new System.Drawing.Size(44, 13);
            this.lblKhoilopmoi.TabIndex = 1;
            this.lblKhoilopmoi.Text = "Khối lớp";
            // 
            // cmbLopmoi
            // 
            this.cmbLopmoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbLopmoi.FormattingEnabled = true;
            this.cmbLopmoi.Location = new System.Drawing.Point(112, 96);
            this.cmbLopmoi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbLopmoi.Name = "cmbLopmoi";
            this.cmbLopmoi.Size = new System.Drawing.Size(148, 21);
            this.cmbLopmoi.TabIndex = 0;
            this.cmbLopmoi.SelectedIndexChanged += new System.EventHandler(this.cmbLopmoi_SelectedIndexChanged);
            // 
            // lblNamhocmoi
            // 
            this.lblNamhocmoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNamhocmoi.AutoSize = true;
            this.lblNamhocmoi.Location = new System.Drawing.Point(13, 30);
            this.lblNamhocmoi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNamhocmoi.Name = "lblNamhocmoi";
            this.lblNamhocmoi.Size = new System.Drawing.Size(48, 13);
            this.lblNamhocmoi.TabIndex = 1;
            this.lblNamhocmoi.Text = "Năm học";
            // 
            // frmPL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmPL";
            this.Text = "Phân lớp";
            this.Load += new System.EventHandler(this.frmPL_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGvLopcu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGvLopmoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevExpress.XtraBars.Docking2010.WindowsUIButtonPanel windowsUIButtonPanel1;
        private System.Windows.Forms.Panel panel1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private System.Windows.Forms.Label lblLopcu;
        private System.Windows.Forms.Label lblKhoilopcu;
        private System.Windows.Forms.Label lblNamhoccu;
        private System.Windows.Forms.ComboBox cmbLopcu;
        private System.Windows.Forms.ComboBox cmbKhoilopcu;
        private System.Windows.Forms.ComboBox cmbNamhoccu;
        private System.Windows.Forms.Panel panel2;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private System.Windows.Forms.Label lblLopmoi;
        private System.Windows.Forms.ComboBox cmbNamhocmoi;
        private System.Windows.Forms.ComboBox cmbKhoilopmoi;
        private System.Windows.Forms.Label lblKhoilopmoi;
        private System.Windows.Forms.ComboBox cmbLopmoi;
        private System.Windows.Forms.Label lblNamhocmoi;
        private System.Windows.Forms.DataGridView dGvLopcu;
        private System.Windows.Forms.DataGridView dGvLopmoi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMahocsinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenhocsinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGioiTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNgaysinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNoisinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDienthoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDiachi;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
    }
}