﻿namespace QLHS
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraBars.PopupMenu popupMenuHome;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.btnQLND = new DevExpress.XtraBars.BarButtonItem();
            this.btnDoimatkhau = new DevExpress.XtraBars.BarButtonItem();
            this.btnSaoluudulieu = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhuchoidulieu = new DevExpress.XtraBars.BarButtonItem();
            this.btnDangxuat = new DevExpress.XtraBars.BarButtonItem();
            this.btnThoat = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.imgCL1 = new DevExpress.Utils.ImageCollection(this.components);
            this.btnLophoc = new DevExpress.XtraBars.BarButtonItem();
            this.btnKhoilop = new DevExpress.XtraBars.BarButtonItem();
            this.btnHocki = new DevExpress.XtraBars.BarButtonItem();
            this.btnNamhoc = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.btnDiem = new DevExpress.XtraBars.BarButtonItem();
            this.btnKetqua = new DevExpress.XtraBars.BarButtonItem();
            this.btnHocluc = new DevExpress.XtraBars.BarButtonItem();
            this.btnHanhkiem = new DevExpress.XtraBars.BarButtonItem();
            this.btnDantoc = new DevExpress.XtraBars.BarButtonItem();
            this.btnTongiao = new DevExpress.XtraBars.BarButtonItem();
            this.btnKQHKtheolop = new DevExpress.XtraBars.BarButtonItem();
            this.btnKQHKtheomon = new DevExpress.XtraBars.BarButtonItem();
            this.btnKQCNtheolop = new DevExpress.XtraBars.BarButtonItem();
            this.btnKQCNtheomon = new DevExpress.XtraBars.BarButtonItem();
            this.btnDSHS = new DevExpress.XtraBars.BarButtonItem();
            this.btnDSGV = new DevExpress.XtraBars.BarButtonItem();
            this.btnDSlop = new DevExpress.XtraBars.BarButtonItem();
            this.btnTracuuGV = new DevExpress.XtraBars.BarButtonItem();
            this.btntracuuHS = new DevExpress.XtraBars.BarButtonItem();
            this.btnHDSD = new DevExpress.XtraBars.BarButtonItem();
            this.btnThongtinphanmem = new DevExpress.XtraBars.BarButtonItem();
            this.btnLienhe = new DevExpress.XtraBars.BarButtonItem();
            this.btnMonhoc = new DevExpress.XtraBars.BarButtonItem();
            this.btnQDtuoi = new DevExpress.XtraBars.BarButtonItem();
            this.btnQDsiso = new DevExpress.XtraBars.BarButtonItem();
            this.btnQDthangdiem = new DevExpress.XtraBars.BarButtonItem();
            this.btnThongtintruonghoc = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.btnHocSinh = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhanLop = new DevExpress.XtraBars.BarButtonItem();
            this.btnGiaoVien = new DevExpress.XtraBars.BarButtonItem();
            this.applicationMenu1 = new DevExpress.XtraBars.Ribbon.ApplicationMenu(this.components);
            this.button1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.btGiaoVien = new DevExpress.XtraBars.BarButtonItem();
            this.btNhapDiemChung = new DevExpress.XtraBars.BarButtonItem();
            this.btNhapDiemRieng = new DevExpress.XtraBars.BarButtonItem();
            this.btmQuiDInhCHung = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhuckhao = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup7 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rbHocSinh = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup13 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup14 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup9 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup10 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rbQuyDinh = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup11 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage4 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.defaultLookAndFeel1 = new DevExpress.LookAndFeel.DefaultLookAndFeel(this.components);
            this.xtraTable = new DevExpress.XtraTabbedMdi.XtraTabbedMdiManager(this.components);
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPageGroup8 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup12 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            popupMenuHome = new DevExpress.XtraBars.PopupMenu(this.components);
            ((System.ComponentModel.ISupportInitialize)(popupMenuHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgCL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTable)).BeginInit();
            this.SuspendLayout();
            // 
            // popupMenuHome
            // 
            popupMenuHome.ItemLinks.Add(this.btnQLND);
            popupMenuHome.ItemLinks.Add(this.btnDoimatkhau);
            popupMenuHome.ItemLinks.Add(this.btnSaoluudulieu);
            popupMenuHome.ItemLinks.Add(this.btnPhuchoidulieu);
            popupMenuHome.ItemLinks.Add(this.btnDangxuat);
            popupMenuHome.ItemLinks.Add(this.btnThoat);
            popupMenuHome.Name = "popupMenuHome";
            popupMenuHome.OptionsMultiColumn.ImageHorizontalAlignment = DevExpress.Utils.Drawing.ItemHorizontalAlignment.Left;
            popupMenuHome.OptionsMultiColumn.LargeImages = DevExpress.Utils.DefaultBoolean.True;
            popupMenuHome.Ribbon = this.ribbonControl1;
            // 
            // btnQLND
            // 
            this.btnQLND.Caption = "Quản lý người dùng";
            this.btnQLND.Id = 33;
            this.btnQLND.ImageOptions.ImageIndex = 46;
            this.btnQLND.ImageOptions.LargeImage = global::QLHS.Properties.Resources.User;
            this.btnQLND.Name = "btnQLND";
            this.btnQLND.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnQLND_ItemClick);
            // 
            // btnDoimatkhau
            // 
            this.btnDoimatkhau.Caption = "Đổi mật khẩu";
            this.btnDoimatkhau.Id = 34;
            this.btnDoimatkhau.ImageOptions.ImageIndex = 42;
            this.btnDoimatkhau.ImageOptions.LargeImage = global::QLHS.Properties.Resources.pass;
            this.btnDoimatkhau.Name = "btnDoimatkhau";
            this.btnDoimatkhau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDoimatkhau_ItemClick);
            // 
            // btnSaoluudulieu
            // 
            this.btnSaoluudulieu.Caption = "Sao lưu dữ liệu";
            this.btnSaoluudulieu.Id = 35;
            this.btnSaoluudulieu.ImageOptions.ImageIndex = 44;
            this.btnSaoluudulieu.ImageOptions.LargeImage = global::QLHS.Properties.Resources.saoludulieu;
            this.btnSaoluudulieu.Name = "btnSaoluudulieu";
            // 
            // btnPhuchoidulieu
            // 
            this.btnPhuchoidulieu.Caption = "Phục hồi dữ liệu";
            this.btnPhuchoidulieu.Id = 36;
            this.btnPhuchoidulieu.ImageOptions.ImageIndex = 43;
            this.btnPhuchoidulieu.ImageOptions.LargeImage = global::QLHS.Properties.Resources.phuchoidulieu;
            this.btnPhuchoidulieu.Name = "btnPhuchoidulieu";
            // 
            // btnDangxuat
            // 
            this.btnDangxuat.AllowRightClickInMenu = false;
            this.btnDangxuat.Caption = "Đăng xuất";
            this.btnDangxuat.Id = 38;
            this.btnDangxuat.ImageOptions.ImageIndex = 45;
            this.btnDangxuat.ImageOptions.LargeImage = global::QLHS.Properties.Resources.User_logout;
            this.btnDangxuat.Name = "btnDangxuat";
            this.btnDangxuat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDangxuat_ItemClick);
            // 
            // btnThoat
            // 
            this.btnThoat.Caption = "Thoát";
            this.btnThoat.Id = 37;
            this.btnThoat.ImageOptions.ImageIndex = 41;
            this.btnThoat.ImageOptions.LargeImage = global::QLHS.Properties.Resources.exit;
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThoat_ItemClick);
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ApplicationButtonDropDownControl = popupMenuHome;
            this.ribbonControl1.ApplicationIcon = global::QLHS.Properties.Resources.Home;
            this.ribbonControl1.ButtonGroupsVertAlign = DevExpress.Utils.VertAlignment.Top;
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Images = this.imgCL1;
            this.ribbonControl1.ImeMode = System.Windows.Forms.ImeMode.On;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.btnLophoc,
            this.btnKhoilop,
            this.btnHocki,
            this.btnNamhoc,
            this.barButtonItem5,
            this.btnDiem,
            this.btnKetqua,
            this.btnHocluc,
            this.btnHanhkiem,
            this.btnDantoc,
            this.btnTongiao,
            this.btnKQHKtheolop,
            this.btnKQHKtheomon,
            this.btnKQCNtheolop,
            this.btnKQCNtheomon,
            this.btnDSHS,
            this.btnDSGV,
            this.btnDSlop,
            this.btnTracuuGV,
            this.btntracuuHS,
            this.btnHDSD,
            this.btnThongtinphanmem,
            this.btnLienhe,
            this.btnQLND,
            this.btnDoimatkhau,
            this.btnSaoluudulieu,
            this.btnPhuchoidulieu,
            this.btnThoat,
            this.btnDangxuat,
            this.btnMonhoc,
            this.btnQDtuoi,
            this.btnQDsiso,
            this.btnQDthangdiem,
            this.btnThongtintruonghoc,
            this.barButtonItem1,
            this.btnHocSinh,
            this.btnPhanLop,
            this.btnGiaoVien,
            this.button1,
            this.barButtonItem4,
            this.btGiaoVien,
            this.btNhapDiemChung,
            this.btNhapDiemRieng,
            this.btmQuiDInhCHung,
            this.barButtonItem6,
            this.barButtonItem7,
            this.btnPhuckhao});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.ribbonControl1.MaxItemId = 67;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1,
            this.ribbonPage2,
            this.ribbonPage3,
            this.rbQuyDinh,
            this.ribbonPage4});
            this.ribbonControl1.SetPopupContextMenu(this.ribbonControl1, popupMenuHome);
            this.ribbonControl1.PopupShowMode = DevExpress.XtraBars.PopupShowMode.Inplace;
            this.ribbonControl1.ShowToolbarCustomizeItem = false;
            this.ribbonControl1.Size = new System.Drawing.Size(1122, 146);
            this.ribbonControl1.Toolbar.ShowCustomizeItem = false;
            // 
            // imgCL1
            // 
            this.imgCL1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imgCL1.ImageStream")));
            this.imgCL1.Images.SetKeyName(0, "book.ico");
            this.imgCL1.Images.SetKeyName(1, "charts_folder_badged.ico");
            this.imgCL1.Images.SetKeyName(2, "dangnhap.jpg");
            this.imgCL1.Images.SetKeyName(3, "dantoc.ico");
            this.imgCL1.Images.SetKeyName(4, "dantoc.png");
            this.imgCL1.Images.SetKeyName(5, "diem.png");
            this.imgCL1.Images.SetKeyName(6, "dsgiaovien.ico");
            this.imgCL1.Images.SetKeyName(7, "dshocsinh.png");
            this.imgCL1.Images.SetKeyName(8, "dslop.ico");
            this.imgCL1.Images.SetKeyName(9, "gameux.dll_I00d3_0409.ico");
            this.imgCL1.Images.SetKeyName(10, "hanhkiem.png");
            this.imgCL1.Images.SetKeyName(11, "hocki.ico");
            this.imgCL1.Images.SetKeyName(12, "Home.ico");
            this.imgCL1.Images.SetKeyName(13, "hoscinh.png");
            this.imgCL1.Images.SetKeyName(14, "huongdan.ico");
            this.imgCL1.Images.SetKeyName(15, "infotruong.png");
            this.imgCL1.Images.SetKeyName(16, "ketqua.ico");
            this.imgCL1.Images.SetKeyName(17, "ketquahockilop.ico");
            this.imgCL1.Images.SetKeyName(18, "ketquahockimon.ico");
            this.imgCL1.Images.SetKeyName(19, "khoilop.png");
            this.imgCL1.Images.SetKeyName(20, "kqcanam.png");
            this.imgCL1.Images.SetKeyName(21, "kqhocki.ico");
            this.imgCL1.Images.SetKeyName(22, "library.ico");
            this.imgCL1.Images.SetKeyName(23, "lienhe.png");
            this.imgCL1.Images.SetKeyName(24, "lop.ico");
            this.imgCL1.Images.SetKeyName(25, "namhoc.ico");
            this.imgCL1.Images.SetKeyName(26, "Parental.ico");
            this.imgCL1.Images.SetKeyName(27, "pass.ico");
            this.imgCL1.Images.SetKeyName(28, "phanlop.ico");
            this.imgCL1.Images.SetKeyName(29, "qdsiso.ico");
            this.imgCL1.Images.SetKeyName(30, "quydinhdiem.png");
            this.imgCL1.Images.SetKeyName(31, "Spring Icon 124.ico");
            this.imgCL1.Images.SetKeyName(32, "stats.ico");
            this.imgCL1.Images.SetKeyName(33, "teacher.png");
            this.imgCL1.Images.SetKeyName(34, "thongtin.ico");
            this.imgCL1.Images.SetKeyName(35, "timgiaovien.png");
            this.imgCL1.Images.SetKeyName(36, "timhocsinh.png");
            this.imgCL1.Images.SetKeyName(37, "tuoi.ico");
            this.imgCL1.Images.SetKeyName(38, "User Account.ico");
            this.imgCL1.Images.SetKeyName(39, "Windows Live Messenger.ico");
            this.imgCL1.Images.SetKeyName(40, "wpcao.dll_I0079_0409.ico");
            this.imgCL1.Images.SetKeyName(41, "exit.png");
            this.imgCL1.Images.SetKeyName(42, "pass.png");
            this.imgCL1.Images.SetKeyName(43, "phuchoidulieu.png");
            this.imgCL1.Images.SetKeyName(44, "saoludulieu.png");
            this.imgCL1.Images.SetKeyName(45, "User_logout.png");
            this.imgCL1.Images.SetKeyName(46, "User.ico");
            // 
            // btnLophoc
            // 
            this.btnLophoc.Caption = "Lớp học";
            this.btnLophoc.Id = 1;
            this.btnLophoc.ImageOptions.LargeImage = global::QLHS.Properties.Resources.lop;
            this.btnLophoc.Name = "btnLophoc";
            this.btnLophoc.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnLophoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnLophoc_ItemClick);
            // 
            // btnKhoilop
            // 
            this.btnKhoilop.Caption = "Khối lớp";
            this.btnKhoilop.Id = 2;
            this.btnKhoilop.ImageOptions.LargeImage = global::QLHS.Properties.Resources.khoilop;
            this.btnKhoilop.Name = "btnKhoilop";
            this.btnKhoilop.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnKhoilop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKhoilop_ItemClick);
            // 
            // btnHocki
            // 
            this.btnHocki.Caption = "Học kỳ";
            this.btnHocki.Id = 3;
            this.btnHocki.ImageOptions.LargeImage = global::QLHS.Properties.Resources.hocki;
            this.btnHocki.Name = "btnHocki";
            this.btnHocki.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnHocki.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHocki_ItemClick);
            // 
            // btnNamhoc
            // 
            this.btnNamhoc.Caption = "Năm học";
            this.btnNamhoc.Id = 4;
            this.btnNamhoc.ImageOptions.LargeImage = global::QLHS.Properties.Resources.namhoc;
            this.btnNamhoc.Name = "btnNamhoc";
            this.btnNamhoc.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnNamhoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNamhoc_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "Môn học";
            this.barButtonItem5.Id = 5;
            this.barButtonItem5.ImageOptions.LargeImage = global::QLHS.Properties.Resources.book;
            this.barButtonItem5.Name = "barButtonItem5";
            this.barButtonItem5.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnDiem
            // 
            this.btnDiem.Caption = "Điểm";
            this.btnDiem.Id = 6;
            this.btnDiem.ImageOptions.LargeImage = global::QLHS.Properties.Resources.diem;
            this.btnDiem.Name = "btnDiem";
            this.btnDiem.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnDiem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDiem_ItemClick);
            // 
            // btnKetqua
            // 
            this.btnKetqua.Caption = "Kết quả";
            this.btnKetqua.Id = 8;
            this.btnKetqua.ImageOptions.LargeImage = global::QLHS.Properties.Resources.ketqua;
            this.btnKetqua.Name = "btnKetqua";
            this.btnKetqua.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnKetqua.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKetqua_ItemClick);
            // 
            // btnHocluc
            // 
            this.btnHocluc.Caption = "Học lực";
            this.btnHocluc.Id = 9;
            this.btnHocluc.ImageOptions.LargeImage = global::QLHS.Properties.Resources.stats;
            this.btnHocluc.Name = "btnHocluc";
            this.btnHocluc.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnHocluc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHocluc_ItemClick);
            // 
            // btnHanhkiem
            // 
            this.btnHanhkiem.Caption = "Hạnh kiểm";
            this.btnHanhkiem.Id = 10;
            this.btnHanhkiem.ImageOptions.LargeImage = global::QLHS.Properties.Resources.hanhkiem;
            this.btnHanhkiem.Name = "btnHanhkiem";
            this.btnHanhkiem.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnHanhkiem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHanhkiem_ItemClick);
            // 
            // btnDantoc
            // 
            this.btnDantoc.Caption = "Dân tộc";
            this.btnDantoc.Id = 11;
            this.btnDantoc.ImageOptions.LargeImage = global::QLHS.Properties.Resources.dantoc1;
            this.btnDantoc.Name = "btnDantoc";
            // 
            // btnTongiao
            // 
            this.btnTongiao.Caption = "Tôn giáo";
            this.btnTongiao.Id = 12;
            this.btnTongiao.ImageOptions.LargeImage = global::QLHS.Properties.Resources.dantoc;
            this.btnTongiao.Name = "btnTongiao";
            // 
            // btnKQHKtheolop
            // 
            this.btnKQHKtheolop.Caption = "Kết quả học kỳ theo lớp học";
            this.btnKQHKtheolop.Id = 13;
            this.btnKQHKtheolop.ImageOptions.LargeImage = global::QLHS.Properties.Resources.ketquahockilop;
            this.btnKQHKtheolop.Name = "btnKQHKtheolop";
            this.btnKQHKtheolop.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnKQHKtheolop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKQHKtheolop_ItemClick);
            // 
            // btnKQHKtheomon
            // 
            this.btnKQHKtheomon.Caption = "Kết quả học kỳ theo môn học";
            this.btnKQHKtheomon.Id = 14;
            this.btnKQHKtheomon.ImageOptions.LargeImage = global::QLHS.Properties.Resources.ketquahockimon;
            this.btnKQHKtheomon.Name = "btnKQHKtheomon";
            this.btnKQHKtheomon.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnKQHKtheomon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKQHKtheomon_ItemClick);
            // 
            // btnKQCNtheolop
            // 
            this.btnKQCNtheolop.Caption = "Kết quả cả năm theo lớp học";
            this.btnKQCNtheolop.Id = 15;
            this.btnKQCNtheolop.ImageOptions.LargeImage = global::QLHS.Properties.Resources.kqcanam;
            this.btnKQCNtheolop.Name = "btnKQCNtheolop";
            this.btnKQCNtheolop.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnKQCNtheolop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKQCNtheolop_ItemClick);
            // 
            // btnKQCNtheomon
            // 
            this.btnKQCNtheomon.Caption = "Kết quả cả năm theo môn học";
            this.btnKQCNtheomon.Id = 16;
            this.btnKQCNtheomon.ImageOptions.LargeImage = global::QLHS.Properties.Resources.kqhocki;
            this.btnKQCNtheomon.Name = "btnKQCNtheomon";
            this.btnKQCNtheomon.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnKQCNtheomon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKQCNtheomon_ItemClick);
            // 
            // btnDSHS
            // 
            this.btnDSHS.Caption = "Danh sách học sinh";
            this.btnDSHS.Id = 17;
            this.btnDSHS.ImageOptions.LargeImage = global::QLHS.Properties.Resources.dshocsinh;
            this.btnDSHS.Name = "btnDSHS";
            this.btnDSHS.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnDSHS.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDSHS_ItemClick);
            // 
            // btnDSGV
            // 
            this.btnDSGV.Caption = "Danh sách giáo viên";
            this.btnDSGV.Id = 18;
            this.btnDSGV.ImageOptions.LargeImage = global::QLHS.Properties.Resources.dsgiaovien;
            this.btnDSGV.Name = "btnDSGV";
            this.btnDSGV.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnDSGV.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDSGV_ItemClick);
            // 
            // btnDSlop
            // 
            this.btnDSlop.Caption = "Danh sách lớp";
            this.btnDSlop.Id = 19;
            this.btnDSlop.ImageOptions.LargeImage = global::QLHS.Properties.Resources.dslop;
            this.btnDSlop.Name = "btnDSlop";
            this.btnDSlop.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnDSlop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnDSlop_ItemClick);
            // 
            // btnTracuuGV
            // 
            this.btnTracuuGV.Caption = "Phân công";
            this.btnTracuuGV.Id = 20;
            this.btnTracuuGV.ImageOptions.LargeImage = global::QLHS.Properties.Resources.timgiaovien;
            this.btnTracuuGV.Name = "btnTracuuGV";
            this.btnTracuuGV.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btntracuuHS
            // 
            this.btntracuuHS.Caption = "Xem điểm";
            this.btntracuuHS.Id = 21;
            this.btntracuuHS.ImageOptions.LargeImage = global::QLHS.Properties.Resources.timhocsinh;
            this.btntracuuHS.Name = "btntracuuHS";
            this.btntracuuHS.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btntracuuHS.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btntracuuHS_ItemClick);
            // 
            // btnHDSD
            // 
            this.btnHDSD.Caption = "Hướng dẫn sử dụng phần mềm";
            this.btnHDSD.Id = 22;
            this.btnHDSD.ImageOptions.LargeImage = global::QLHS.Properties.Resources.huongdan;
            this.btnHDSD.Name = "btnHDSD";
            this.btnHDSD.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnThongtinphanmem
            // 
            this.btnThongtinphanmem.Caption = "Thông tin phân mềm";
            this.btnThongtinphanmem.Id = 23;
            this.btnThongtinphanmem.ImageOptions.LargeImage = global::QLHS.Properties.Resources.thongtin;
            this.btnThongtinphanmem.Name = "btnThongtinphanmem";
            this.btnThongtinphanmem.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnThongtinphanmem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThongtinphanmem_ItemClick);
            // 
            // btnLienhe
            // 
            this.btnLienhe.Caption = "Liên hệ";
            this.btnLienhe.Id = 24;
            this.btnLienhe.ImageOptions.LargeImage = global::QLHS.Properties.Resources.lienhe;
            this.btnLienhe.Name = "btnLienhe";
            this.btnLienhe.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnMonhoc
            // 
            this.btnMonhoc.Caption = "Môn học";
            this.btnMonhoc.Id = 38;
            this.btnMonhoc.ImageOptions.LargeImage = global::QLHS.Properties.Resources.book;
            this.btnMonhoc.Name = "btnMonhoc";
            this.btnMonhoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnMonhoc_ItemClick);
            // 
            // btnQDtuoi
            // 
            this.btnQDtuoi.Caption = "Quy định về độ tuổi";
            this.btnQDtuoi.Id = 39;
            this.btnQDtuoi.ImageOptions.LargeImage = global::QLHS.Properties.Resources.tuoi;
            this.btnQDtuoi.Name = "btnQDtuoi";
            this.btnQDtuoi.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnQDtuoi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnQDtuoi_ItemClick);
            // 
            // btnQDsiso
            // 
            this.btnQDsiso.Caption = "Quy định về sĩ số";
            this.btnQDsiso.Id = 40;
            this.btnQDsiso.ImageOptions.LargeImage = global::QLHS.Properties.Resources.qdsiso;
            this.btnQDsiso.Name = "btnQDsiso";
            this.btnQDsiso.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnQDsiso.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnQDsiso_ItemClick);
            // 
            // btnQDthangdiem
            // 
            this.btnQDthangdiem.Caption = "Quy định về thang điểm";
            this.btnQDthangdiem.Id = 41;
            this.btnQDthangdiem.ImageOptions.LargeImage = global::QLHS.Properties.Resources.quydinhdiem;
            this.btnQDthangdiem.Name = "btnQDthangdiem";
            this.btnQDthangdiem.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnThongtintruonghoc
            // 
            this.btnThongtintruonghoc.Caption = "Thông tin trường học";
            this.btnThongtintruonghoc.Id = 42;
            this.btnThongtintruonghoc.ImageOptions.LargeImage = global::QLHS.Properties.Resources.infotruong;
            this.btnThongtintruonghoc.Name = "btnThongtintruonghoc";
            this.btnThongtintruonghoc.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnThongtintruonghoc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThongtintruonghoc_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 43;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // btnHocSinh
            // 
            this.btnHocSinh.Caption = "Học Sinh";
            this.btnHocSinh.Id = 53;
            this.btnHocSinh.ImageOptions.Image = global::QLHS.Properties.Resources.dshocsinh1;
            this.btnHocSinh.Name = "btnHocSinh";
            this.btnHocSinh.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnHocSinh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHocSinh_ItemClick);
            // 
            // btnPhanLop
            // 
            this.btnPhanLop.Caption = "Phân Lớp";
            this.btnPhanLop.Id = 54;
            this.btnPhanLop.ImageOptions.Image = global::QLHS.Properties.Resources.phanlop1;
            this.btnPhanLop.Name = "btnPhanLop";
            this.btnPhanLop.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnPhanLop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPhanLop_ItemClick);
            // 
            // btnGiaoVien
            // 
            this.btnGiaoVien.Caption = "Giáo Viên";
            this.btnGiaoVien.DropDownControl = this.applicationMenu1;
            this.btnGiaoVien.Id = 55;
            this.btnGiaoVien.Name = "btnGiaoVien";
            // 
            // applicationMenu1
            // 
            this.applicationMenu1.ItemLinks.Add(this.barButtonItem1);
            this.applicationMenu1.Name = "applicationMenu1";
            this.applicationMenu1.Ribbon = this.ribbonControl1;
            // 
            // button1
            // 
            this.button1.Caption = "None";
            this.button1.Id = 56;
            this.button1.ImageOptions.Image = global::QLHS.Properties.Resources.giaovien;
            this.button1.Name = "button1";
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "barButtonItem4";
            this.barButtonItem4.Id = 58;
            this.barButtonItem4.Name = "barButtonItem4";
            // 
            // btGiaoVien
            // 
            this.btGiaoVien.Caption = "Giáo Viên";
            this.btGiaoVien.Id = 59;
            this.btGiaoVien.ImageOptions.Image = global::QLHS.Properties.Resources.giaovien;
            this.btGiaoVien.Name = "btGiaoVien";
            this.btGiaoVien.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btGiaoVien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btGiaoVien_ItemClick);
            // 
            // btNhapDiemChung
            // 
            this.btNhapDiemChung.Caption = "Nhập Điểm Chung";
            this.btNhapDiemChung.Id = 60;
            this.btNhapDiemChung.ImageOptions.Image = global::QLHS.Properties.Resources.diem1;
            this.btNhapDiemChung.Name = "btNhapDiemChung";
            this.btNhapDiemChung.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btNhapDiemChung.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btNhapDiemChung_ItemClick);
            // 
            // btNhapDiemRieng
            // 
            this.btNhapDiemRieng.Caption = "Nhập Điểm Riêng";
            this.btNhapDiemRieng.Id = 61;
            this.btNhapDiemRieng.ImageOptions.Image = global::QLHS.Properties.Resources.monhoc;
            this.btNhapDiemRieng.Name = "btNhapDiemRieng";
            this.btNhapDiemRieng.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btNhapDiemRieng.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btNhapDiemRieng_ItemClick);
            // 
            // btmQuiDInhCHung
            // 
            this.btmQuiDInhCHung.Caption = "Quy định chung";
            this.btmQuiDInhCHung.Id = 62;
            this.btmQuiDInhCHung.ImageOptions.Image = global::QLHS.Properties.Resources.huongdan1;
            this.btmQuiDInhCHung.Name = "btmQuiDInhCHung";
            this.btmQuiDInhCHung.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btmQuiDInhCHung.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btmQuiDInhCHung_ItemClick);
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "Phân công";
            this.barButtonItem6.Id = 64;
            this.barButtonItem6.ImageOptions.LargeImage = global::QLHS.Properties.Resources.phancong;
            this.barButtonItem6.Name = "barButtonItem6";
            this.barButtonItem6.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Caption = "Phân công";
            this.barButtonItem7.Id = 65;
            this.barButtonItem7.ImageOptions.LargeImage = global::QLHS.Properties.Resources.phancong;
            this.barButtonItem7.Name = "barButtonItem7";
            this.barButtonItem7.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.barButtonItem7.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem7_ItemClick);
            // 
            // btnPhuckhao
            // 
            this.btnPhuckhao.Caption = "Phúc khảo điểm";
            this.btnPhuckhao.Id = 66;
            this.btnPhuckhao.ImageOptions.Image = global::QLHS.Properties.Resources.edit;
            this.btnPhuckhao.ImageOptions.LargeImage = global::QLHS.Properties.Resources.edit;
            this.btnPhuckhao.Name = "btnPhuckhao";
            this.btnPhuckhao.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1,
            this.ribbonPageGroup5,
            this.ribbonPageGroup6,
            this.ribbonPageGroup7,
            this.rbHocSinh,
            this.ribbonPageGroup13,
            this.ribbonPageGroup14});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Quản lý";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.btnLophoc);
            this.ribbonPageGroup1.ItemLinks.Add(this.btnKhoilop);
            this.ribbonPageGroup1.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Lớp - Khối lớp";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.btnHocki);
            this.ribbonPageGroup5.ItemLinks.Add(this.btnNamhoc);
            this.ribbonPageGroup5.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "Năm học";
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.ItemLinks.Add(this.btnMonhoc);
            this.ribbonPageGroup6.ItemLinks.Add(this.btnDiem);
            this.ribbonPageGroup6.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            this.ribbonPageGroup6.Text = "Môn học";
            // 
            // ribbonPageGroup7
            // 
            this.ribbonPageGroup7.ItemLinks.Add(this.btnKetqua);
            this.ribbonPageGroup7.ItemLinks.Add(this.btnHocluc);
            this.ribbonPageGroup7.ItemLinks.Add(this.btnHanhkiem);
            this.ribbonPageGroup7.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup7.Name = "ribbonPageGroup7";
            this.ribbonPageGroup7.Text = "Kết quả";
            // 
            // rbHocSinh
            // 
            this.rbHocSinh.ItemLinks.Add(this.btnHocSinh);
            this.rbHocSinh.ItemLinks.Add(this.btnPhanLop);
            this.rbHocSinh.Name = "rbHocSinh";
            this.rbHocSinh.Text = "Học Sinh";
            // 
            // ribbonPageGroup13
            // 
            this.ribbonPageGroup13.ItemLinks.Add(this.btGiaoVien);
            this.ribbonPageGroup13.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup13.Name = "ribbonPageGroup13";
            this.ribbonPageGroup13.Text = "Giáo Viên";
            // 
            // ribbonPageGroup14
            // 
            this.ribbonPageGroup14.ItemLinks.Add(this.btNhapDiemRieng);
            this.ribbonPageGroup14.ItemLinks.Add(this.btNhapDiemChung);
            this.ribbonPageGroup14.Name = "ribbonPageGroup14";
            this.ribbonPageGroup14.Text = "Điểm";
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2,
            this.ribbonPageGroup9,
            this.ribbonPageGroup10});
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Thống kê";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.btnKQHKtheolop);
            this.ribbonPageGroup2.ItemLinks.Add(this.btnKQHKtheomon);
            this.ribbonPageGroup2.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "Kết quả học kỳ";
            // 
            // ribbonPageGroup9
            // 
            this.ribbonPageGroup9.ItemLinks.Add(this.btnKQCNtheolop);
            this.ribbonPageGroup9.ItemLinks.Add(this.btnKQCNtheomon);
            this.ribbonPageGroup9.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup9.Name = "ribbonPageGroup9";
            this.ribbonPageGroup9.Text = "Kết quả cuối năm";
            // 
            // ribbonPageGroup10
            // 
            this.ribbonPageGroup10.ItemLinks.Add(this.btnDSHS);
            this.ribbonPageGroup10.ItemLinks.Add(this.btnDSGV);
            this.ribbonPageGroup10.ItemLinks.Add(this.btnDSlop);
            this.ribbonPageGroup10.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup10.Name = "ribbonPageGroup10";
            this.ribbonPageGroup10.Text = "Xuất danh sách";
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3});
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "Tra cứu";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.btntracuuHS);
            this.ribbonPageGroup3.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Tra cứu thông tin";
            // 
            // rbQuyDinh
            // 
            this.rbQuyDinh.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup11});
            this.rbQuyDinh.Name = "rbQuyDinh";
            this.rbQuyDinh.Text = "Quy định";
            // 
            // ribbonPageGroup11
            // 
            this.ribbonPageGroup11.ItemLinks.Add(this.btmQuiDInhCHung);
            this.ribbonPageGroup11.ItemLinks.Add(this.btnQDtuoi);
            this.ribbonPageGroup11.ItemLinks.Add(this.btnQDsiso);
            this.ribbonPageGroup11.ItemLinks.Add(this.btnThongtintruonghoc);
            this.ribbonPageGroup11.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup11.Name = "ribbonPageGroup11";
            this.ribbonPageGroup11.Text = "Quy Định";
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup4});
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Text = "Trợ giúp";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.btnHDSD);
            this.ribbonPageGroup4.ItemLinks.Add(this.btnThongtinphanmem);
            this.ribbonPageGroup4.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.OneRow;
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Text = "Giúp đỡ";
            // 
            // defaultLookAndFeel1
            // 
            this.defaultLookAndFeel1.LookAndFeel.SkinName = "Office 2016 Colorful";
            // 
            // xtraTable
            // 
            this.xtraTable.MdiParent = this;
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Hạnh kiểm";
            this.barButtonItem2.Id = 10;
            this.barButtonItem2.ImageOptions.LargeImage = global::QLHS.Properties.Resources.hanhkiem;
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "Hạnh kiểm";
            this.barButtonItem3.Id = 10;
            this.barButtonItem3.ImageOptions.LargeImage = global::QLHS.Properties.Resources.hanhkiem;
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // ribbonPageGroup8
            // 
            this.ribbonPageGroup8.ImageOptions.Image = global::QLHS.Properties.Resources.giaovien;
            this.ribbonPageGroup8.ItemLinks.Add(this.btnGiaoVien);
            this.ribbonPageGroup8.Name = "ribbonPageGroup8";
            this.ribbonPageGroup8.Text = "Giáo Viên";
            // 
            // ribbonPageGroup12
            // 
            this.ribbonPageGroup12.ItemLinks.Add(this.btnHocSinh);
            this.ribbonPageGroup12.ItemLinks.Add(this.btnPhanLop);
            this.ribbonPageGroup12.Name = "ribbonPageGroup12";
            this.ribbonPageGroup12.Text = "Học SInh";
            // 
            // frmMain
            // 
            this.Appearance.BackColor = System.Drawing.Color.Teal;
            this.Appearance.Options.UseBackColor = true;
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1122, 584);
            this.Controls.Add(this.ribbonControl1);
            this.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmMain";
            this.Ribbon = this.ribbonControl1;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUẢN LÝ HỌC SINH";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(popupMenuHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgCL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.Utils.ImageCollection imgCL1;
        private DevExpress.XtraBars.BarButtonItem btnLophoc;
        private DevExpress.XtraBars.BarButtonItem btnKhoilop;
        private DevExpress.XtraBars.BarButtonItem btnHocki;
        private DevExpress.XtraBars.BarButtonItem btnNamhoc;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem btnDiem;
        private DevExpress.XtraBars.BarButtonItem btnKetqua;
        private DevExpress.XtraBars.BarButtonItem btnHocluc;
        private DevExpress.XtraBars.BarButtonItem btnHanhkiem;
        private DevExpress.XtraBars.BarButtonItem btnDantoc;
        private DevExpress.XtraBars.BarButtonItem btnTongiao;
        private DevExpress.XtraBars.BarButtonItem btnKQHKtheolop;
        private DevExpress.XtraBars.BarButtonItem btnKQHKtheomon;
        private DevExpress.XtraBars.BarButtonItem btnKQCNtheolop;
        private DevExpress.XtraBars.BarButtonItem btnKQCNtheomon;
        private DevExpress.XtraBars.BarButtonItem btnDSHS;
        private DevExpress.XtraBars.BarButtonItem btnDSGV;
        private DevExpress.XtraBars.BarButtonItem btnDSlop;
        private DevExpress.XtraBars.BarButtonItem btnTracuuGV;
        private DevExpress.XtraBars.BarButtonItem btntracuuHS;
        private DevExpress.XtraBars.BarButtonItem btnHDSD;
        private DevExpress.XtraBars.BarButtonItem btnThongtinphanmem;
        private DevExpress.XtraBars.BarButtonItem btnLienhe;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup7;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup9;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup10;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.LookAndFeel.DefaultLookAndFeel defaultLookAndFeel1;
        private DevExpress.XtraBars.BarButtonItem btnQLND;
        private DevExpress.XtraBars.BarButtonItem btnDoimatkhau;
        private DevExpress.XtraBars.BarButtonItem btnSaoluudulieu;
        private DevExpress.XtraBars.BarButtonItem btnPhuchoidulieu;
        private DevExpress.XtraBars.BarButtonItem btnThoat;
        private DevExpress.XtraBars.BarButtonItem btnDangxuat;
        private DevExpress.XtraBars.BarButtonItem btnMonhoc;
        private DevExpress.XtraBars.BarButtonItem btnQDtuoi;
        private DevExpress.XtraBars.BarButtonItem btnQDsiso;
        private DevExpress.XtraBars.BarButtonItem btnQDthangdiem;
        private DevExpress.XtraBars.BarButtonItem btnThongtintruonghoc;
        private DevExpress.XtraBars.Ribbon.RibbonPage rbQuyDinh;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup11;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.Ribbon.ApplicationMenu applicationMenu1;
        private DevExpress.XtraTabbedMdi.XtraTabbedMdiManager xtraTable;
        private DevExpress.XtraBars.BarButtonItem btnHocSinh;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rbHocSinh;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem btnPhanLop;
        private DevExpress.XtraBars.BarButtonItem btnGiaoVien;
        private DevExpress.XtraBars.BarButtonItem button1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup8;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup12;
        private DevExpress.XtraBars.BarButtonItem btGiaoVien;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup13;
        private DevExpress.XtraBars.BarButtonItem btNhapDiemChung;
        private DevExpress.XtraBars.BarButtonItem btNhapDiemRieng;
        private DevExpress.XtraBars.BarButtonItem btmQuiDInhCHung;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
        private DevExpress.XtraBars.BarButtonItem btnPhuckhao;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup14;
    }
}

